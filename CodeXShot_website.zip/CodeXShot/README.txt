CodeXShot website

1. Open index.html in a browser to preview.
2. Edit "Your Name", the About text, skills, project cards and social links.
3. In index.html, replace YOUR_EMAIL@example.com with your email to activate the contact email link.
4. To publish free with GitHub Pages:
   - Create/sign in to GitHub and make a new public repository named codexshot.
   - Upload index.html and this README.
   - Open repository Settings > Pages.
   - Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
   - Wait for GitHub Pages to publish. Your public URL will appear in Settings > Pages.
5. Share that published URL with friends.

This is a static personal portfolio starter. Do not publish private phone numbers, home address, passwords or other sensitive information.
